package com.walletapp.service;

import com.walletapp.model.UserWallet;
import org.springframework.stereotype.Service;

@Service
public class WalletService {
    private UserWallet wallet = new UserWallet();

    public double getBalance() {
        return wallet.getBalance();
    }

    public void addMoney(double amount) {
        wallet.addMoney(amount);
    }

    public boolean withdrawMoney(double amount) {
        return wallet.withdrawMoney(amount);
    }

    public Object getTransactionHistory() {
        return wallet.getTransactions();
    }
}