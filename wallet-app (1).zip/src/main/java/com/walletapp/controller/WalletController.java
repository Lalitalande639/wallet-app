package com.walletapp.controller;

import com.walletapp.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/wallet")
public class WalletController {

    @Autowired
    private WalletService walletService;

    @GetMapping("/balance")
    public ResponseEntity<Double> getBalance() {
        return ResponseEntity.ok(walletService.getBalance());
    }

    @PostMapping("/add")
    public ResponseEntity<String> addMoney(@RequestParam double amount) {
        walletService.addMoney(amount);
        return ResponseEntity.ok("Amount added: " + amount);
    }

    @PostMapping("/withdraw")
    public ResponseEntity<String> withdrawMoney(@RequestParam double amount) {
        boolean success = walletService.withdrawMoney(amount);
        if (success) {
            return ResponseEntity.ok("Amount withdrawn: " + amount);
        } else {
            return ResponseEntity.badRequest().body("Insufficient balance");
        }
    }

    @GetMapping("/transactions")
    public ResponseEntity<Object> getTransactions() {
        return ResponseEntity.ok(walletService.getTransactionHistory());
    }
}