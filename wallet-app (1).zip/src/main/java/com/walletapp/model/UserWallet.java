package com.walletapp.model;

import java.util.ArrayList;
import java.util.List;

public class UserWallet {
    private double balance = 0;
    private List<Transaction> transactions = new ArrayList<>();

    public double getBalance() {
        return balance;
    }

    public void addMoney(double amount) {
        balance += amount;
        transactions.add(new Transaction("Credit", amount));
    }

    public boolean withdrawMoney(double amount) {
        if (balance >= amount) {
            balance -= amount;
            transactions.add(new Transaction("Debit", amount));
            return true;
        }
        return false;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }
}